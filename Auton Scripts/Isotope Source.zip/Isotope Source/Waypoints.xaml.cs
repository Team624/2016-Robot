﻿/*
 * Created by SharpDevelop.
 * User: team624
 * Date: 07/23/2014
 * Time: 20:17
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace Isotope
{
	/// <summary>
	/// Interaction logic for Waypoints.xaml
	/// </summary>
	public partial class Waypoints : Window
	{
		public Waypoints()
		{
			InitializeComponent();
		}
	}
}